const path = require('path');
const { name, github } = require('./a');

console.log(name, github, path.basename(github));

// qiufeng https://github.com/hua1995116