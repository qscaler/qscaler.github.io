import {unused} from './effect';
console.log(42);
