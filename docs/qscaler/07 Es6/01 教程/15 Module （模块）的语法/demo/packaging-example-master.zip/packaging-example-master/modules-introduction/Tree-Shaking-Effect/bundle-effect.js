console.log(unused());

function unused() {
    console.log(1);
}

console.log(42);
