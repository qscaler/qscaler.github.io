export let foo = 1;
import * as a from './a.js';
console.log(a);