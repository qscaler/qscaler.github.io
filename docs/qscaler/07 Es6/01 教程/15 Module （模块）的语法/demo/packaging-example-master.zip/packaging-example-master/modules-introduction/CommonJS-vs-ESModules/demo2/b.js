export let age = 1;

setTimeout(() => {
    age = 2;
}, 10);