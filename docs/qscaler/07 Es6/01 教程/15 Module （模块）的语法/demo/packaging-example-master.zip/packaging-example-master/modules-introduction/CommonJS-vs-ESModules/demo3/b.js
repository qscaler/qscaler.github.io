export let age = 1;
console.log('b.js 先执行');