console.log(42);
