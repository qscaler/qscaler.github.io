import * as utils from './utils';

const array = [1,2,3,1,2,3]

console.log(utils.arrayUnique(array));
