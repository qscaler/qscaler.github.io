const name = 'qiufeng'

module.exports = {
    name,
    github: 'https://github.com/hua1995116'
}