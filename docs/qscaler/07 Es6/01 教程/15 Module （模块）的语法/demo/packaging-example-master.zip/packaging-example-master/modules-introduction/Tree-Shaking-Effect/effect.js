console.log(unused());

export function unused() {
    console.log(1);
}