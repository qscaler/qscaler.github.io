console.log('a.js')
import { age } from './b.js';