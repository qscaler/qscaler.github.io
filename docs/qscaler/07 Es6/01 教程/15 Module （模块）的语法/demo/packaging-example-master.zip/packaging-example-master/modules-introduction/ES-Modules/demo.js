export function name() {
    return 'qiufeng';
}

export function github() {
    return 'https://github.com/hua1995116';
}