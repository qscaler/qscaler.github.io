let age = 1;

setTimeout(() => {
    age = 18;
}, 10);

module.exports = {
    age
}