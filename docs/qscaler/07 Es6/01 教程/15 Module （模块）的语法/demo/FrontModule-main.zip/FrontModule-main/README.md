# FrontModule

practice for IIFE AMD CMD UMD

## how to use?

配置http server的location为/website/www

将所有文件放入到linux服务器的/website/www目录下，然后通过以下URL访问：

linuxserverIP=你的linux服务器的IP地址

1. IIFE

http://linuxserverIP/IIFE/index.html

2. AMD

http://linuxserverIP/AMD/index.html

3. CMD

http://linuxserverIP/CMD/index.html

4. UMD

http://linuxserverIP/UMD/index.html


5. ES6

ES6有很多例子，因此xxxxx表示后缀，具体参考代码。

http://linuxserverIP/ES6/index_xxxxx.html