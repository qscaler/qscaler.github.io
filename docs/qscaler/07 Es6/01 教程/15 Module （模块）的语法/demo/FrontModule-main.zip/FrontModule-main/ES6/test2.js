function test2(){
    console.log("test2!");
}
test2();