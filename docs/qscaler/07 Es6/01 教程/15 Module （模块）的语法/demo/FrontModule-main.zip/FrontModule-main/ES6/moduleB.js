function moduleB(){
    console.log("This is ModuleB!");
}
moduleB();
let helloB = function(){
    console.log("This is helloB!");
}

export {helloB};

let helloB_str="helloB";

export default helloB_str;

/* iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii
oooooooooooooooooooooooooooooooooooooo
oooooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooo */