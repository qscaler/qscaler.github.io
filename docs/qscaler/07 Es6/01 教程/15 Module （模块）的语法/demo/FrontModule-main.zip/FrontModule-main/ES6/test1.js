function test1(){
    console.log("test1!");
}
test1();