
var moduleA = require('./moduleA');
console.log(moduleA.add(1, 2));