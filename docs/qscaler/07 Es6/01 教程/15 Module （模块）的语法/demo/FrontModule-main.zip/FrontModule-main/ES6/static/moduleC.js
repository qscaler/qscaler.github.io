function moduleC(){
    console.log("This is ModuleC!");
}
moduleC();
export let helloC = function(){
    console.log("This is helloC!");
}

