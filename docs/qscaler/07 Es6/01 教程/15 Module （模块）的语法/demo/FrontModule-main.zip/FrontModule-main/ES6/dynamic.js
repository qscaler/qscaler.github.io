
if ("1.0"===version){
    import("./moduleA.js")
}else{
    import("./moduleB.js")
}


